package com.example;



import org.bson.Document;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

public class Main {
    public static void main(String[] args) {
        // Create a MongoDB client
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017/");
        
        // Get the database
        MongoDatabase database = mongoClient.getDatabase("appointmentscheduler");
        
        // Get the collection
        MongoCollection<Document> collection = database.getCollection("appointments");
        
        // Create documents to insert
        Document appointment1 = new Document("date", "2024-12-12")
            .append("time", "2:00 pm")
            .append("location", "Coimbatore");

        Document appointment2 = new Document("date", "2024-11-11")
            .append("time", "10:00 am")
            .append("location", "Chennai");

        Document appointment3 = new Document("date", "2024-12-11")
            .append("time", "11:00 am")
            .append("location", "Bangalore");
        
        
        // Insert documents
        collection.insertOne(appointment1);
        collection.insertOne(appointment2);
        collection.insertOne(appointment3);

        
        System.out.println("Documents inserted successfully!");

        // List the documents
        FindIterable<Document> documents = collection.find();
        for (Document doc : documents) {
            System.out.println(doc.toJson());
        }
        // Update the documents
         collection.updateOne(
            Filters.eq("location", "Bangalore"),
            Updates.set("time", "4:00 pm")
        );

        System.out.println("\nTime updated successfully for location: Bangalore");



        // List the updated documents
         System.out.println("\nDocuments after update:");
        for (Document doc : collection.find()) {
            System.out.println(doc.toJson());
        }

        // Close the connection
        mongoClient.close();
    }
}